package cs.dit.controller;

import cs.dit.member.MemberDTO;

import cs.dit.service.*;

import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("*.do")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 1,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
public class FrontController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String uri = request.getRequestURI();
        String context = request.getContextPath();
        String command = uri.substring(context.length() + 1);
        System.out.println("제발 좀 되라 command: " + command); 
        
        Service service = null;
        String viewPage = null;

        // ✅ GET 요청 처리
        if (command.equals("index.do")) {
            service = new PostListService();
            try {
                service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
            viewPage = "index.jsp";

        } else if (command.equals("login.do")) {
            viewPage = "login.jsp";

        } else if (command.equals("register.do")) {
            viewPage = "register.jsp";

        } else if (command.equals("logout.do")) {
            HttpSession session = request.getSession();
            session.invalidate();
            response.sendRedirect("index.do");
            return;

        }else if (command.equals("edit_profile.do")) {
            service = new EditProfileService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        

        }  else if (command.equals("mypage.do")) {
            service = new MypageService();
            try {
                viewPage = service.execute(request, response); // "mypage.jsp" expected
            } catch (Exception e) {
                e.printStackTrace();
            }
        

        } else if (command.equals("fitBoardList.do")) {
            service = new FitBoardListService();
            try {
            	System.out.println("11");
                service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
            viewPage = "fit_board_list.jsp";

     /*   } else if (command.equals("fitboardwrite.do")) {
        	service = new FitBoardWriteService();
        	try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }
        	System.out.println("....");
        	viewPage = "fit_board_write.jsp"; */
            
        } else if (command.equals("fitboardwrite.do")) {
            // 핏보드 글쓰기 페이지로 이동 (로그인 체크)
            HttpSession session = request.getSession();
            MemberDTO user = (MemberDTO) session.getAttribute("user");
            if (user == null) {
                response.sendRedirect("login.do");
                return;
            }
            viewPage = "fit_board_write.jsp";
            

        } else if (command.equals("post_detail.do")) {
            service = new PostDetailService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (command.equals("postWrite.do")) {
            HttpSession session = request.getSession();
            MemberDTO user = (MemberDTO) session.getAttribute("user");
            if (user == null) {
                response.sendRedirect("login.do");
                return;
            }
            viewPage = "post_write.jsp";
        }

        // ✅ 공통 View 처리
        processView(viewPage, request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String uri = request.getRequestURI();
        String context = request.getContextPath();
        String command = uri.substring(context.length() + 1);

        Service service = null;
        String viewPage = null;

        // ✅ POST 요청 처리
        if (command.equals("login.do")) {
            service = new LoginService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (command.equals("register.do")) {
            service = new RegisterService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (command.equals("edit_profile.do")) {
            service = new EditProfileService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }

       /* } else if (command.equals("fitboardwrite.do")) {
            service = new FitBoardWriteService();
            try {
                service.execute(request, response);
                response.sendRedirect("fitboardwrite.jsp");
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }       */
            
        } else if (command.equals("fitboardwrite.do")) {
            // 핏보드 글 작성 처리
            HttpSession session = request.getSession();
            MemberDTO user = (MemberDTO) session.getAttribute("user");
            if (user == null) {
                response.sendRedirect("login.do");
                return;
            }
            
            service = new FitBoardWriteService();
            try {
                viewPage = service.execute(request, response);
                // 성공 시 핏보드 목록으로 리다이렉트
                if (viewPage == null || viewPage.equals("success")) {
                    response.sendRedirect("fitBoardList.do");
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "핏보드 글 작성 중 오류가 발생했습니다.");
                viewPage = "fit_board_write.jsp";
            }

        } else if (command.equals("postWrite.do")) {
            service = new PostWriteService();
            try {
                viewPage = service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "게시글 작성 중 오류 발생");
                viewPage = "error.jsp";
            }
        } /*else if (command.equals("fitBoardList.do")) {
            service = new PostWriteService();
            try {
                service.execute(request, response);
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "게시글 작성 중 오류 발생");
                viewPage = "fit_board_list.jsp";
            }
        }*/
        // ✅ 공통 View 처리
        processView(viewPage, request, response);
    }

    // ✅ View 경로 및 이동 방식 처리 (공통 메서드)
    private void processView(String viewPage, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (viewPage != null) {
            if (viewPage.startsWith("redirect:")) {
                String target = viewPage.substring("redirect:".length());
                response.sendRedirect(target);
            } else {
                if (!viewPage.startsWith("/WEB-INF/views/")) {
                    viewPage = "/WEB-INF/views/" + viewPage;
                }
                RequestDispatcher rd = request.getRequestDispatcher(viewPage);
                rd.forward(request, response);
            }
        }
    }
}