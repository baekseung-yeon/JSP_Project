package cs.dit.service;

import cs.dit.member.MemberDAO;

import cs.dit.member.MemberDTO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterService implements Service {
	

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");

        try {
            // 👉 name 속성 그대로 받아오기
            String id = request.getParameter("id");
            String password = request.getParameter("password");
            String nickname = request.getParameter("nickname");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            
            System.out.println("id: " + id);
            System.out.println("password: " + password);
            System.out.println("nickname: " + nickname);
            System.out.println("email: " + email);
            System.out.println("phone: " + phone);


            // 👉 DTO에 올바르게 담기
            MemberDTO dto = new MemberDTO();
            dto.setId(id);
            dto.setPassword(password);
            dto.setNickname(nickname);
            dto.setPhone(phone);
            dto.setEmail(email);

            // 👉 DB 저장
            MemberDAO dao = new MemberDAO();
            dao.insert(dto);

            // 성공 시 로그인 페이지로 이동
            return "/WEB-INF/views/login.jsp";

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "회원가입 중 오류 발생: " + e.getMessage());
            return "/WEB-INF/views/error.jsp";
        }
    }
    
}
