package cs.dit.service;

import cs.dit.fitboard.FitBoardDAO;
import cs.dit.fitboard.FitBoardDTO;
import cs.dit.member.MemberDTO;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class FitBoardWriteService implements Service {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        try {
            request.setCharacterEncoding("UTF-8");
            HttpSession session = request.getSession();

           
            MemberDTO user = (MemberDTO) session.getAttribute("user");
            System.out.println(user);
            if (user == null) {
                response.sendRedirect("login.do");
                return null;
            }

            String writer = user.getId();

            String title = request.getParameter("title");
            String content = request.getParameter("content");

         // 파일 업로드 처리
            List<String> fileNames = new ArrayList<>();
            String uploadPath = request.getServletContext().getRealPath("/uploads");
            
            // uploads 디렉토리 생성
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            
            try {
                for (Part part : request.getParts()) {
                    if ("attachments".equals(part.getName()) && part.getSize() > 0) {
                        String originalFileName = Paths.get(part.getSubmittedFileName()).getFileName().toString();
                        
                        // 파일명 중복 방지를 위해 UUID 추가
                        String fileExtension = "";
                        int lastDotIndex = originalFileName.lastIndexOf(".");
                        if (lastDotIndex > 0) {
                            fileExtension = originalFileName.substring(lastDotIndex);
                            originalFileName = originalFileName.substring(0, lastDotIndex);
                        }
                        
                        String uniqueFileName = originalFileName + "_" + UUID.randomUUID().toString() + fileExtension;
                        String fullUploadPath = uploadPath + File.separator + uniqueFileName;
                        
                        // 파일 저장
                        part.write(fullUploadPath);
                        fileNames.add(uniqueFileName);
                        
                        System.out.println("파일 업로드 완료: " + uniqueFileName);
                    }
                }
            } catch (Exception e) {
                System.err.println("파일 업로드 중 오류 발생: " + e.getMessage());
                e.printStackTrace();
                // 파일 업로드 실패해도 글 작성은 계속 진행
            }
            
            // 첨부파일 목록을 문자열로 변환
            String attachedFiles = fileNames.isEmpty() ? null : String.join(",", fileNames);
            
            System.out.println("=== FitBoardWriteService 실행 ===");
            System.out.println("작성자: " + writer);
            System.out.println("제목: " + title);
            System.out.println("내용: " + content);
            System.out.println("첨부파일: " + attachedFiles);
            
            // DTO 생성 및 데이터베이스 저장
            FitBoardDTO dto = new FitBoardDTO();
            dto.setTitle(title.trim());
            dto.setContent(content.trim());
            dto.setWriter(writer);
            dto.setFiles(attachedFiles); // 첨부파일 정보 설정
            
            FitBoardDAO dao = new FitBoardDAO();
            boolean insertResult = dao.insert(dto);
            
            if (insertResult) {
                System.out.println("핏보드 글 작성 성공");
                // 성공 시 목록 페이지로 리다이렉트 (컨트롤러에서 처리)
                return "success";
            } else {
                System.err.println("핏보드 글 작성 실패");
                request.setAttribute("error", "글 작성에 실패했습니다. 다시 시도해주세요.");
                return "fit_board_write.jsp";
            }
            
        } catch (IOException e) {
            System.err.println("FitBoardWriteService 실행 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "시스템 오류가 발생했습니다.");
            return "fit_board_write.jsp";
        } catch (Exception e) {
            System.err.println("예상치 못한 오류 발생: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "예상치 못한 오류가 발생했습니다.");
            return "fit_board_write.jsp";
        }
    }
    }

