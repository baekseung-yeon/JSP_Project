package cs.dit.service;

import cs.dit.post.PostDAO;
import cs.dit.post.PostDTO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PostDetailService implements Service {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String postIdStr = request.getParameter("id");
        if (postIdStr == null || postIdStr.isEmpty()) {
            request.setAttribute("error", "잘못된 요청입니다.");
            return "/WEB-INF/views/error.jsp";
        }

        int postId = Integer.parseInt(postIdStr);
        PostDAO dao = new PostDAO();
        PostDTO post = dao.getPostById(postId);

        if (post == null) {
            request.setAttribute("error", "해당 게시글을 찾을 수 없습니다.");
            return "/WEB-INF/views/error.jsp";
        }

        request.setAttribute("post", post);
        return "/WEB-INF/views/post_detail.jsp";
    }
}
