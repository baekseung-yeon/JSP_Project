package cs.dit.service;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import javax.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class EditProfileService implements Service {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO user = (MemberDTO) session.getAttribute("user");
        
        if (user == null) {
            return "redirect:login.do";
        }
        
        String action = request.getParameter("action");
        
        // action이 없으면 그냥 페이지 표시
        if (action == null) {
            request.setAttribute("user", user);
            return "edit_profile.jsp";
        }
        
        MemberDAO dao = new MemberDAO();
        String redirectUrl = "edit_profile.do";
        
        try {
            switch (action) {
                case "uploadImage":
                    Part filePart = request.getPart("profileImage");
                    if (filePart != null && filePart.getSize() > 0) {
                        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                        String savePath = request.getServletContext().getRealPath("/images/profiles") + File.separator + fileName;
                        filePart.write(savePath);
                        String dbPath = "images/profiles/" + fileName;
                        dao.updateProfileImage(user.getId(), dbPath);
                        user.setProfileImg(dbPath);
                        redirectUrl += "?success=image";
                    }
                    break;
                    
                case "deleteImage":
                    dao.updateProfileImage(user.getId(), null);
                    user.setProfileImg(null);
                    redirectUrl += "?success=image";
                    break;
                    
                case "updateNickname":
                    String nickname = request.getParameter("nickname");
                    if (nickname != null && !nickname.trim().isEmpty()) {
                        dao.updateNickname(user.getId(), nickname);
                        user.setNickname(nickname);
                        redirectUrl += "?success=nickname";
                    }
                    break;
                    
                case "updateIntro":
                    String intro = request.getParameter("intro");
                    dao.updateIntro(user.getId(), intro);
                    user.setIntro(intro);
                    redirectUrl += "?success=intro";
                    break;
                    
                case "deleteMember":
                    dao.deleteMember(user.getId());
                    session.invalidate();
                    response.sendRedirect("login.do");
                    return null;
            }
            
            // 세션 업데이트 후 리다이렉트
            session.setAttribute("user", user);
            response.sendRedirect(redirectUrl);
            return null;
            
        } catch (IOException | ServletException e) {
            e.printStackTrace();
            request.setAttribute("error", "처리 중 오류가 발생했습니다.");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "데이터베이스 오류가 발생했습니다.");
        }
        
        // 오류 발생 시 다시 폼 페이지로
        request.setAttribute("user", user);
        return "edit_profile.jsp";
    }
}