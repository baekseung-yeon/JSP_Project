package cs.dit.service;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;


public class LoginService implements Service {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String id = request.getParameter("id");
        String password = request.getParameter("password");

        MemberDAO dao = new MemberDAO();
        MemberDTO user = dao.getMemberByIdAndPassword(id, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            return "redirect:index.do"; // 로그인 성공 시 홈으로
        } else {
        	request.setAttribute("errorMessage", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "/WEB-INF/views/login.jsp"; // 로그인 실패 시 다시 로그인 페이지로
        }
    }
}
