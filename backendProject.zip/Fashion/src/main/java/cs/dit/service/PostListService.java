package cs.dit.service;

import cs.dit.post.PostDAO;
import cs.dit.post.PostDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public class PostListService implements Service {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");
        
        PostDAO dao = new PostDAO();
        String sort = request.getParameter("sort");
        List<PostDTO> postList;
        
        try {
            if ("like".equals(sort)) {
                postList = dao.getPostsByLike();
                request.setAttribute("sort", "like");
            } else {
                postList = dao.getPostsByDate();
                request.setAttribute("sort", "date");
            }
            
            // 디버깅용 로그
            System.out.println("IndexService - Retrieved posts count: " + postList.size());
            for (PostDTO post : postList) {
                System.out.println("Post ID: " + post.getPostId() + ", Writer: " + post.getWriterNickname() + ", Images: " + (post.getImagePaths() != null ? post.getImagePaths().size() : 0));
            }
            
            request.setAttribute("postList", postList);
            
        } catch (Exception e) {
            e.printStackTrace();
            // 에러 발생 시 빈 리스트라도 설정
            postList = new java.util.ArrayList<>();
            request.setAttribute("postList", postList);
            request.setAttribute("error", "게시글을 불러오는 중 오류가 발생했습니다.");
        }
        
        return "index.jsp";
    }
}