package cs.dit.service;

import cs.dit.member.MemberDTO;
import cs.dit.post.PostDAO;
import cs.dit.post.PostDTO;

import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PostWriteService implements Service {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        MemberDTO user = (MemberDTO) session.getAttribute("user");

        if (user == null) {
            return "redirect:login.do";
        }

        // 업로드 경로 설정 및 확인
        String uploadPath = request.getServletContext().getRealPath("/upload");
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            boolean created = uploadDir.mkdirs();
            System.out.println("Upload 폴더 생성: " + created + ", 경로: " + uploadPath);
        }
        System.out.println("Upload 경로: " + uploadPath);
        System.out.println("Upload 폴더 존재: " + uploadDir.exists());
        System.out.println("Upload 폴더 쓰기 가능: " + uploadDir.canWrite());

        String tags = request.getParameter("tags");
        String content = request.getParameter("content");

        try {
            Part filePart = request.getPart("image"); // input name="image"
            
            // DTO에 값 세팅
            PostDTO post = new PostDTO();
            post.setWriterId(user.getId());
            post.setContent(content);
            post.setTagsFromString(tags); // String을 List<String>으로 변환하여 저장
            
            List<String> imageList = new ArrayList<>();
            
            // 파일이 업로드된 경우에만 처리
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = extractFileName(filePart);
                
                if (fileName != null && !fileName.isEmpty()) {
                    // 파일명 중복 방지를 위해 UUID 추가
                    String fileExtension = "";
                    int lastDotIndex = fileName.lastIndexOf(".");
                    if (lastDotIndex > 0) {
                        fileExtension = fileName.substring(lastDotIndex);
                        fileName = fileName.substring(0, lastDotIndex);
                    }
                    
                    String uniqueFileName = fileName + "_" + UUID.randomUUID().toString() + fileExtension;
                    
                    // 실제 파일 저장 경로
                    String fullPath = uploadPath + File.separator + uniqueFileName;
                    
                    // 실제 파일 저장
                    filePart.write(fullPath);
                    
                    // 파일 저장 확인
                    File savedFile = new File(fullPath);
                    System.out.println("파일 저장 시도: " + fullPath);
                    System.out.println("파일 저장 성공: " + savedFile.exists());
                    System.out.println("파일 크기: " + savedFile.length() + " bytes");
                    
                    // DB에 저장할 경로 (웹에서 접근 가능한 경로)
                    String webPath = "upload/" + uniqueFileName;
                    imageList.add(webPath);
                    
                    System.out.println("DB 저장 경로: " + webPath);
                }
            }
            
            post.setImagePaths(imageList);

            // DB에 저장
            PostDAO dao = new PostDAO();
            boolean success = dao.insert(post);
            
            if (success) {
                System.out.println("게시글 저장 성공");
                return "redirect:index.do";
            } else {
                System.out.println("게시글 저장 실패");
                request.setAttribute("error", "게시글 저장에 실패했습니다.");
                return "postWrite.jsp";
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "파일 업로드 중 오류가 발생했습니다: " + e.getMessage());
            return "postWrite.jsp";
        }
    }

    private String extractFileName(Part part) {
        String header = part.getHeader("content-disposition");
        if (header == null) return null;
        
        for (String content : header.split(";")) {
            if (content.trim().startsWith("filename")) {
                String filename = content.substring(content.indexOf("=") + 1).trim();
                // 따옴표 제거
                if (filename.startsWith("\"") && filename.endsWith("\"")) {
                    filename = filename.substring(1, filename.length() - 1);
                }
                return filename;
            }
        }
        return null;
    }
}