package cs.dit.service;

import cs.dit.member.MemberDTO;
import cs.dit.post.PostDAO;
import cs.dit.post.PostDTO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.ArrayList;

public class MypageService implements Service {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            System.out.println("=== MypageService 시작 ===");
            
            HttpSession session = request.getSession(false);
            MemberDTO user = (session != null) ? (MemberDTO) session.getAttribute("user") : null;

            // 디버깅용 로그
            System.out.println("Session 존재: " + (session != null));
            System.out.println("User 존재: " + (user != null));

            if (user != null) {
                System.out.println("User ID: " + user.getId());
                System.out.println("User Nickname: " + user.getNickname());
            }

            // 로그인 사용자 처리
            if (user != null) {
                String loginId = user.getId();
                System.out.println("로그인 사용자 게시물 조회 시작: " + loginId);

                try {
                    PostDAO dao = new PostDAO();
                    List<PostDTO> postList = dao.getPostsByWriter(loginId);

                    System.out.println("조회된 게시물 수: " + postList.size());
                    for (PostDTO post : postList) {
                        System.out.println("- Post ID: " + post.getPostId() +
                                ", Images: " + (post.getImagePaths() != null ? post.getImagePaths().size() : 0));
                    }

                    request.setAttribute("user", user);
                    request.setAttribute("postList", postList);
                    System.out.println("로그인 사용자 데이터 설정 완료");
                    
                } catch (Exception dbError) {
                    System.err.println("데이터베이스 조회 중 에러: " + dbError.getMessage());
                    dbError.printStackTrace();
                    
                    // DB 에러가 나도 기본 정보는 설정해주기
                    request.setAttribute("user", user);
                    request.setAttribute("postList", new ArrayList<PostDTO>());
                    request.setAttribute("dbError", "게시물을 불러올 수 없습니다.");
                }
                
            } else {
                // 로그인이 안 되어 있는 경우 - 테스트용 임시 데이터
                System.out.println("로그인 안됨 - 임시 사용자 생성 (테스트용)");

                MemberDTO tempUser = new MemberDTO();
                tempUser.setId("h0ngt0graphy");
                tempUser.setNickname("h0ngt0graphy");
                tempUser.setEmail("h0ngt0graphy145@privaterelay.appleid.com");
                tempUser.setProfileImg("photo/my-img01.jpg");

                request.setAttribute("user", tempUser);
                request.setAttribute("postList", new ArrayList<PostDTO>());
                request.setAttribute("isTestUser", true); // 테스트 사용자임을 표시
                
                System.out.println("임시 사용자 데이터 설정 완료");
            }

            System.out.println("=== MypageService 완료 ===");
            return "mypage.jsp";

        } catch (Exception e) {
            System.err.println("=== MypageService 전체 에러 ===");
            System.err.println("에러 메시지: " + e.getMessage());
            e.printStackTrace();

            // 에러가 나도 최소한의 데이터는 설정해주기
            MemberDTO errorUser = new MemberDTO();
            errorUser.setId("error_user");
            errorUser.setNickname("오류 발생");
            errorUser.setEmail("error@example.com");
            
            request.setAttribute("user", errorUser);
            request.setAttribute("postList", new ArrayList<PostDTO>());
            request.setAttribute("error", "마이페이지 로드 중 오류가 발생했습니다: " + e.getMessage());
            request.setAttribute("errorStackTrace", java.util.Arrays.toString(e.getStackTrace()));

            return "mypage.jsp";
        }
    }
}