 package cs.dit.service;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.fitboard.FitBoardDAO;
import cs.dit.fitboard.FitBoardDTO;

import java.util.List;

public class FitBoardListService implements Service {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        FitBoardDAO dao = new FitBoardDAO();
        List<FitBoardDTO> list = dao.getAllPosts();
        return "fit_board.jsp";
    }
}


