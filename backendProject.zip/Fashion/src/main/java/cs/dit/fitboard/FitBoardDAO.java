package cs.dit.fitboard;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class FitBoardDAO {
    
    private Connection getConnection() throws Exception {
        Context initContext = new InitialContext();
        Context envContext = (Context) initContext.lookup("java:comp/env");
        DataSource ds = (DataSource) envContext.lookup("jdbc/fashion_project");
        return ds.getConnection();
    }
    
    // 커뮤니티 게시글 등록 (수정됨)
    public void insertPost(FitBoardDTO dto) {
        System.out.println("insertPost() 호출됨");
        // ✅ INSERT문으로 수정
        String sql = "INSERT INTO post (writer_id, board_type, title, content, reg_date) VALUES (?, ?, ?, ?, NOW())";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, dto.getWriter());        // writer_id
            pstmt.setString(2, "community");            // board_type  
            pstmt.setString(3, dto.getTitle());         // title
            pstmt.setString(4, dto.getContent());       // content
            
            int result = pstmt.executeUpdate();
            System.out.println("게시글 등록 완료: " + result + "개 행 추가");
            
        } catch (Exception e) {
            System.out.println("게시글 등록 중 오류 발생:");
            e.printStackTrace();
        }
    }
    
    // 커뮤니티 게시글 목록 조회 (수정됨)
    public List<FitBoardDTO> getAllPosts() {
        List<FitBoardDTO> list = new ArrayList<>();
    	String sql = "SELECT p.post_id, p.writer_id, p.title, p.content, p.reg_date, p.like_count, " +
                "m.nickname FROM post p " +
                "LEFT JOIN member m ON p.writer_id = m.id " +
                "WHERE p.board_type = 'community' " +
                "ORDER BY p.reg_date DESC";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                FitBoardDTO dto = new FitBoardDTO();
                dto.setId(rs.getInt("post_id"));
                dto.setWriter(rs.getString("writer_id"));
                dto.setTitle(rs.getString("title"));
                dto.setContent(rs.getString("content"));
                dto.setCreatedAt(rs.getTimestamp("reg_date"));
                list.add(dto);
            }
            
            System.out.println("커뮤니티 게시글 조회 완료: " + list.size() + "개");
            
        } catch (Exception e) {
            System.out.println("게시글 목록 조회 중 오류 발생:");
            e.printStackTrace();
        }
        return list;
    }
    
 
    // 특정 게시글 조회
    public FitBoardDTO getPostById(int postId) {
        String sql = "SELECT p.post_id, p.writer_id, p.title, p.content, p.reg_date, p.like_count, " +
                    "m.nickname FROM post p " +
                    "LEFT JOIN member m ON p.writer_id = m.id " +
                    "WHERE p.post_id = ? AND p.board_type = 'community'";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                FitBoardDTO dto = new FitBoardDTO();
                dto.setId(rs.getInt("post_id"));
                dto.setWriter(rs.getString("writer_id"));
                dto.setTitle(rs.getString("title"));
                dto.setContent(rs.getString("content"));
                dto.setCreatedAt(rs.getTimestamp("reg_date"));
                return dto;
            }
            
        } catch (Exception e) {
            System.out.println("게시글 상세 조회 중 오류 발생:");
            e.printStackTrace();
        }
        return null;
    }
   
    // 기존 insert 메서드 (qa_post용 - 그대로 유지)
    public boolean insert(FitBoardDTO dto) {
        String sql = "INSERT INTO post (writer_id, board_type, title, content, reg_date) VALUES (?, ?, ?, ?, NOW())";
        try (Connection conn = getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql))
        {
            pstmt.setString(1, dto.getWriter());
            pstmt.setString(2, "community");  // ✅ board_type 추가
            pstmt.setString(3, dto.getTitle());
            pstmt.setString(4, dto.getContent());
            
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
		return false;
    }

	/**
	 * @param searchKeyword
	 * @return
	 */
	public List<FitBoardDTO> searchPosts(String searchKeyword) {
		// TODO Auto-generated method stub
		return null;
	}
}