package cs.dit.member;

public class MemberDTO {
    private String id;
    private String password;
    private String email;
    private String nickname;
    private String profileImg;
    private String phone;
    private String intro;  // 이거 하나로 다 처리!
    
    // 기본 생성자
    public MemberDTO() {}
    
    // 생성자
    public MemberDTO(String id, String password, String email, String nickname, String phone) {
        this.id = id;
        this.password = password;
        this.email = email;
        this.nickname = nickname;
        this.phone = phone;
    }
    
    // getter/setter
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    
    public String getProfileImg() { return profileImg; }
    public void setProfileImg(String profileImg) { this.profileImg = profileImg; }
    
    public String getIntro() { return intro; }
    public void setIntro(String intro) { this.intro = intro; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}