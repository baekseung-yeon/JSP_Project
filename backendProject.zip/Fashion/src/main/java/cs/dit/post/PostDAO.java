package cs.dit.post;

import util.DBUtil;
import java.sql.*;
import java.util.*;
import java.util.ArrayList;

public class PostDAO {

    public List<PostDTO> getPostsByLike() throws Exception {
        String sql = "SELECT p.post_id, p.writer_id, p.title, p.reg_date, p.like_count, m.nickname, m.profile_img, pi.image_path, p.tags FROM post p JOIN member m ON p.writer_id = m.id LEFT JOIN post_image pi ON p.post_id = pi.post_id GROUP BY p.post_id ORDER BY p.like_count DESC";
        return fetchPosts(sql);
    }

    public List<PostDTO> getPostsByDate() throws Exception {
        String sql = "SELECT p.post_id, p.writer_id, p.title, p.content, p.reg_date, p.like_count, m.nickname, m.profile_img, pi.image_path, p.tags " +
                     "FROM post p " +
                     "JOIN member m ON p.writer_id = m.id " +
                     "LEFT JOIN post_image pi ON p.post_id = pi.post_id " +
                     "GROUP BY p.post_id " +
                     "ORDER BY p.reg_date DESC";  
        return fetchPosts(sql);
    }


    private List<PostDTO> fetchPosts(String sql) throws Exception {
        List<PostDTO> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                PostDTO post = new PostDTO();
                post.setPostId(rs.getInt("post_id"));
                post.setWriterId(rs.getString("writer_id"));
                post.setWriterNickname(rs.getString("nickname"));
                post.setWriterProfileImg(rs.getString("profile_img"));
                post.setRegDate(rs.getTimestamp("reg_date"));
                post.setLikeCount(rs.getInt("like_count"));
                post.setTagsFromString(rs.getString("tags"));

                // ⭐ 이미지 리스트 생성해서 대표 이미지만 넣기
                List<String> imageList = new ArrayList<>();
                String imagePath = rs.getString("image_path");
                if (imagePath != null && !imagePath.isEmpty()) {
                    imageList.add(imagePath);
                }
                post.setImagePaths(imageList); // 리스트로 세팅

                list.add(post);
            }
        }
        return list;
    }

    
    public List<PostDTO> getPostsByWriter(String writerId) throws Exception {
        String sql = "SELECT p.post_id, p.writer_id, p.title, p.content, p.reg_date, p.like_count, m.nickname, m.profile_img, pi.image_path, p.tags " +
                     "FROM post p " +
                     "JOIN member m ON p.writer_id = m.id " +
                     "LEFT JOIN post_image pi ON p.post_id = pi.post_id " +
                     "WHERE p.writer_id = ? " +
                     "GROUP BY p.post_id " +
                     "ORDER BY p.reg_date DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, writerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                List<PostDTO> list = new ArrayList<>();
                while (rs.next()) {
                    PostDTO post = new PostDTO();
                    post.setPostId(rs.getInt("post_id"));
                    post.setWriterId(rs.getString("writer_id"));
                    post.setWriterNickname(rs.getString("nickname"));
                    post.setWriterProfileImg(rs.getString("profile_img"));
                    post.setLikeCount(rs.getInt("like_count"));
                    post.setTitle(rs.getString("title"));
                    post.setContent(rs.getString("content"));
                    post.setTagsFromString(rs.getString("tags"));
                    post.setRegDate(rs.getTimestamp("reg_date"));

                    // ⭐ 이미지 리스트 세팅
                    String imagePath = rs.getString("image_path");
                    List<String> imageList = new ArrayList<>();
                    if (imagePath != null && !imagePath.isEmpty()) {
                        imageList.add(imagePath);
                    }
                    post.setImagePaths(imageList);

                    list.add(post);
                }
                return list;
            }
        }
    }

    
    public void insertPost(String writerId, String boardType, String title,
            String content, String tags, String imagePath) throws Exception {
    	String postSql = "INSERT INTO post (writer_id, board_type, title, content, tags) VALUES (?, ?, ?, ?, ?)";
    	String imageSql = "INSERT INTO post_image (post_id, image_path) VALUES (?, ?)";

    	try (Connection conn = DBUtil.getConnection()) {
    		conn.setAutoCommit(false); // 트랜잭션 시작

    		try (PreparedStatement postStmt = conn.prepareStatement(postSql, Statement.RETURN_GENERATED_KEYS)) {
    			postStmt.setString(1, writerId);
    			postStmt.setString(2, boardType);
    			postStmt.setString(3, title);
    			postStmt.setString(4, content);
    			postStmt.setString(5, tags);
    			postStmt.executeUpdate();

    			ResultSet rs = postStmt.getGeneratedKeys();
    			int postId = 0;
    			if (rs.next()) postId = rs.getInt(1);

    			if (imagePath != null && !imagePath.isEmpty()) {
    				try (PreparedStatement imgStmt = conn.prepareStatement(imageSql)) {
    					imgStmt.setInt(1, postId);
    					imgStmt.setString(2, imagePath);
    					imgStmt.executeUpdate();
    				}
    			}

    			conn.commit();
    		} catch (Exception e) {
    			conn.rollback();
    			throw e;
    		}
    	}
    }
    
    public PostDTO getPostById(int postId) {
        PostDTO post = null;
        String postSql = """
        	    SELECT p.*, m.nickname, m.profile_img, pi.image_path
        	    FROM post p
        	    JOIN member m ON p.writer_id = m.id
        	    LEFT JOIN post_image pi ON p.post_id = pi.post_id
        	    WHERE p.post_id = ?
        	    LIMIT 1
        	""";


        String imageSql = "SELECT image_path FROM post_image WHERE post_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement postStmt = conn.prepareStatement(postSql);
             PreparedStatement imageStmt = conn.prepareStatement(imageSql)) {

            postStmt.setInt(1, postId);
            ResultSet rs = postStmt.executeQuery();

            if (rs.next()) {
                post = new PostDTO();
                post.setPostId(rs.getInt("post_id"));
                post.setWriterId(rs.getString("writer_id"));
                post.setWriterNickname(rs.getString("nickname"));
                post.setWriterProfileImg(rs.getString("profile_img"));
                post.setTitle(rs.getString("title"));
                post.setContent(rs.getString("content"));
                post.setRegDate(rs.getTimestamp("reg_date"));
                post.setLikeCount(rs.getInt("like_count"));
                post.setTagsFromString(rs.getString("tags"));

                // 이미지 리스트 추가
                imageStmt.setInt(1, postId);
                ResultSet imgRs = imageStmt.executeQuery();
                List<String> imagePaths = new ArrayList<>();
                while (imgRs.next()) {
                    imagePaths.add(imgRs.getString("image_path"));
                }
                post.setImagePaths(imagePaths);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return post;
    }

    
    public PostDTO selectPost(int postId) {
        PostDTO dto = null;

        String postSql = "SELECT * FROM post WHERE post_id = ?";
        String imageSql = "SELECT image_path FROM post_image WHERE post_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement postStmt = conn.prepareStatement(postSql);
             PreparedStatement imageStmt = conn.prepareStatement(imageSql)) {

            postStmt.setInt(1, postId);
            ResultSet rs = postStmt.executeQuery();

            if (rs.next()) {
                dto = new PostDTO();
                dto.setPostId(rs.getInt("post_id"));
                dto.setTitle(rs.getString("title"));
                dto.setContent(rs.getString("content"));
                // 기타 항목들도 설정

                // 이미지 목록 불러오기
                imageStmt.setInt(1, postId);
                ResultSet imgRs = imageStmt.executeQuery();
                List<String> imagePaths = new ArrayList<>();
                while (imgRs.next()) {
                    imagePaths.add(imgRs.getString("image_path"));
                }
                dto.setImagePaths(imagePaths);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dto;
    }
    
    public List<PostDTO> getCommunityPosts() throws Exception {
        String sql = "SELECT p.post_id, p.writer_id, p.title, p.reg_date, p.like_count, m.nickname, pi.image_path " +
                     "FROM post p " +
                     "JOIN member m ON p.writer_id = m.id " +
                     "LEFT JOIN post_image pi ON p.post_id = pi.post_id " +
                     "WHERE board_type = 'community' " +
                     "GROUP BY p.post_id " +
                     "ORDER BY p.reg_date DESC";

        return fetchPosts(sql);
    }

    public boolean insert(PostDTO post) throws Exception {
        String postSql = "INSERT INTO post (writer_id, board_type, title, content, tags) VALUES (?, ?, ?, ?, ?)";
        String imageSql = "INSERT INTO post_image (post_id, image_path) VALUES (?, ?)";

        try (Connection conn = DBUtil.getConnection()) {
            conn.setAutoCommit(false);  // 트랜잭션 시작

            try (PreparedStatement postStmt = conn.prepareStatement(postSql, Statement.RETURN_GENERATED_KEYS)) {
                postStmt.setString(1, post.getWriterId());
                postStmt.setString(2, "photo");  // board_type은 'photo'로 고정
                postStmt.setString(3, post.getTitle() != null ? post.getTitle() : "");
                postStmt.setString(4, post.getContent());
                postStmt.setString(5, post.getTagsAsString());

                postStmt.executeUpdate();

                ResultSet rs = postStmt.getGeneratedKeys();
                int postId = 0;
                if (rs.next()) {
                    postId = rs.getInt(1);
                }

                List<String> imagePaths = post.getImagePaths();
                if (imagePaths != null && !imagePaths.isEmpty()) {
                    try (PreparedStatement imgStmt = conn.prepareStatement(imageSql)) {
                        for (String path : imagePaths) {
                            imgStmt.setInt(1, postId);
                            imgStmt.setString(2, path);
                            imgStmt.addBatch();
                        }
                        imgStmt.executeBatch();
                    }
                }

                conn.commit();
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        }
		return false;
    }





}