package cs.dit.post;

import java.sql.Timestamp;
import java.util.*;

public class PostDTO {
private int postId;
private String writerId;
private String writerNickname;
private String writerProfileImg;
private int likeCount;
private List<String> tags;
private Timestamp regDate;
private String title;
private String content;
private List<String> imagePaths;

public List<String> getImagePaths() {
return imagePaths;
}

public void setImagePaths(List<String> imagePaths) {
this.imagePaths = imagePaths;
}

public int getPostId() {
return postId;
}

public void setPostId(int postId) {
this.postId = postId;
}

public String getWriterId() {
return writerId;
}

public void setWriterId(String writerId) {
this.writerId = writerId;
}

public String getWriterNickname() {
return writerNickname;
}

public void setWriterNickname(String writerNickname) {
this.writerNickname = writerNickname;
}

public String getWriterProfileImg() {
return writerProfileImg;
}

public void setWriterProfileImg(String writerProfileImg) {
this.writerProfileImg = writerProfileImg;
}


public int getLikeCount() {
return likeCount;
}

public void setLikeCount(int likeCount) {
this.likeCount = likeCount;
}

public List<String> getTags() {
return tags;
}

public void setTags(List<String> tags) {
this.tags = tags;
}

public void setTagsFromString(String tagStr) {
if (tagStr == null || tagStr.trim().isEmpty()) {
this.tags = new ArrayList<>();
} else {
this.tags = Arrays.asList(tagStr.split(","));
}
}

public String getTagsAsString() {
if (tags == null || tags.isEmpty()) return "";
return String.join(",", tags);
}

public Timestamp getRegDate() {
return regDate;
}

public void setRegDate(Timestamp regDate) {
this.regDate = regDate;
}

public String getTitle() {
return title;
}

public void setTitle(String title) {
this.title = title;
}

public String getContent() {
return content;
}

public void setContent(String content) {
this.content = content;
}
}